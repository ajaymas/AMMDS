import os
import socket
import threading
import crc16
import time

def receive_File():
	print "Enter 'Y/y' for receiving file:"
	user_Response=raw_input(" ")
	if user_Response[:]=='Y' or user_Response[:]=='y':       
		print "Please enter the host name:"
		host_Name=raw_input()
		flag=0
		with open('dns1.txt') as f:
			for line in f:
				x=map(str,line.split())
				if(x[0]==host_Name):
					ip_Address=x[1]
					port=int(x[2])
					flag=1
					sock_Obj=socket.socket()
					sock_Obj.connect((ip_Address,port))
					th = threading.Thread(target=download, args=("RetdThread",sock_Obj))
					th.start()			
					break
		if(flag==0):
			print "IP Address not found:"
			receive_File()
	else:
		receive_File()



def download(t,sock):
		a=sock.recv(1024)
		#print "Number of files:",a
		a=long(a)
		a1 =a #test53
		while True:
			sock.send("OK")
			data=sock.recv(1024);
			x=data
			print "Receiving file:",x
			x1=map(str,data.split(':'))
			file_name=x1[0]
			file_Size=x1[1]
			filename_size_CRC=x1[2]
			filename_Size=''.join(file_name)
			filename_Size=filename_Size+':'+file_Size
			ycname=crc16.crc16xmodem(filename_Size)
			
			print 'Calculated CRC:',str(ycname)
			print 'Received CRC:',filename_size_CRC
			if str(ycname)==filename_size_CRC: 
				sock.send("nmcrc")
				start_time=time.clock()
				print("downloading data ...");
				print os.path.splitext(file_name)[0]
				print file_name
				if not os.path.exists(os.path.splitext(file_name)[0]):os.makedirs(os.path.splitext(file_name)[0])
				savedPath = os.getcwd()
				os.chdir(os.path.splitext(file_name)[0])
				f = open(file_name, 'wb')
				
				recievd=0
				while recievd < int(file_Size):
					data=sock.recv(1024);
					o=data
					length=len(o)
					print "length:",length
					received_CRC=''
					received_Data=''
					for i in range(length-5,length):
						received_CRC=received_CRC+o[i]
					for i in range(0,length-5):
						received_Data=received_Data+o[i]	
					ycdata=crc16.crc16xmodem(received_Data)
					ycdata=str(ycdata)
					print "Received CRC Packets:",received_CRC
					print "Calculated CRC Packet:-",ycdata
					if(len(ycdata)<5):
						for i in range(5-len(ycdata)):
							ycdata='0'+ycdata
					if str(ycdata)==received_CRC: 
						sock.send("crc");
						recievd=recievd+len(received_Data);
						f.write(received_Data);
						
						#print "Transfered"
					else:
						print 'Filedata packet is currupted for filr',file_name; 
						break
				f.close()
				end_time=time.clock()
				print 'end_time',end_time
				print 'start_time',start_time
				w=end_time-float(start_time)
				print'file transfer time ',w,'s';
			else: 
				print 'File Information packet is currupted for filr',file_name; #CRC
			os.chdir(savedPath);
			#w=s-e;
			#print "File Transfer time:",w,"ms";
			#s1.close();
			a1-=1
			print "Number of files remaining",a1
			if a1 == 0:
				a1 = a
				print"--------------------------------------------"
				print "Files are again getting updated"
			
		sock.close()
		receive_File()


def Main():
		port=5000;
		socket1=socket.socket(); 
		host='10.100.54.79'
		socket1.bind((host,port));
		#socket1.bind((socket.gethostbyname(socket.getfqdn()),port));
		socket1.listen(5);
		
		t1 = threading.Thread(target=receive_File)
		t1.start()
		while True: 
			connection, address = socket1.accept();
			print "Host:<",socket.gethostname(),">is connedted to the host:<",str(address),">"
			t2 = threading.Thread(target=send, args=('RetdThread',connection))
			t2.start() 
		socket1.close() 
		
def send(th,connection):
			#print "Please enter the directory:"
			#directory=raw_input("")
			#print directory
			directory='/home/pgadmin14/Downloads/abc/'
			files = [f for f in os.listdir(directory) if os.path.isfile(os.path.join(directory,f))]
			count=len(files)	
			connection.send(str(count))
			#for file in files:
			k=0
			while True:
				if(k==len(files)):
					time.sleep(10); #test53
					#if(raw_input()=='stop'):
					#	break
					k=0
				file=files[k]
				uresp=connection.recv(1024)
				if uresp[:2] == 'OK':
					print "Sending File-",directory+file; 
					file_Name=directory+file
					size=os.path.getsize(file_Name);
					print size
					filename_Size=''.join(file)
					filename_Size=filename_Size+':'+str(size)
					filename_Size_CRC=crc16.crc16xmodem(filename_Size) 
					filename_Size=filename_Size+':'+str(filename_Size_CRC)
					connection.send(filename_Size);
					uresp = connection.recv(1024)
					if uresp[:5] == 'nmcrc': 
						with open(file_Name, 'rb') as f:
							byte = f.read(1019);
							while byte != "":
								#print "length:",len(byte)
								ybyte=crc16.crc16xmodem(byte)
								ybyte=str(ybyte)
								#print "CRC:",ybyte
								if(len(ybyte)<5):
									for i in range(5-len(ybyte)):
										ybyte='0'+ybyte
								print "CRC:",ybyte
								byte=byte+ybyte
								#print "length:",len(byte)
								
								connection.send(byte);
								uresp=connection.recv(1024)
								#print "last response"
								if uresp[:3] == 'crc':
									#print "in CRC"
									byte = f.read(1019);
									#print "length in CRC:",len(byte)
					
					time.sleep(5);
				k=k+1
			connection.close()
Main()
