import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class PromptTest {
	
	public PromptTest(String command) {
    
try
{
	
    Process process = Runtime.getRuntime().exec(command);
  String data="";
	InputStream is=process.getInputStream();
	InputStreamReader isr=new InputStreamReader(is);
	BufferedReader bfr=new BufferedReader(isr);
	String line;
	while((line=bfr.readLine())!=null){
	data=data+line;
	
}


    String filename=null;
    filename="/home/pgadmin10/socket/ACN/"+command;
    File file=new File(filename);
    FileWriter fw=new FileWriter(file);
    BufferedWriter bw=new BufferedWriter(fw);
    bw.write(data);
    bw.close();
    
} catch (IOException e)
{
    e.printStackTrace();
}

	}

	
}



